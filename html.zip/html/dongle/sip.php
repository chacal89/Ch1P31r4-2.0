<?php
/**
 *
 * =======================================
 * ###################################
 * RAO Telecom
 *
 * @package RAO Dongle Panel
 * @author Ricardo A. Oliveira
 * @copyright Copyright (C) 2015 - 2017 RAO Telecom. All rights reserved.
 * ###################################
 *
 * =======================================
 * raotelecom.com.br <ricardo@raotelecom.com.br>
 * 10/2017
 */

	include 'config.php';
 
?>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF8" />
        <title>RAO - Dongle Panel</title>
		<link rel="stylesheet" media="screen" type="text/css" href="css/jquery-ui.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/styles.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/content.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/table.css" />
       		<link rel="stylesheet" media="screen" type="text/css" href="css/bootstrap.min.css" />
		<script type='text/javascript' src='js/jquery-1.8.3.min.js'></script>
		<script type='text/javascript' src='js/jquery-ui.js'></script>
		<script type='text/javascript' src='js/jquery.ui.datepicker-pt-BR.min.js'></script>
		<script type='text/javascript' src='js/bootstrap.js'></script>
		<script type="text/javascript" language="javascript" src="js/functions.js"></script>

    </head>
    <body style="background-color: #f0f0f0;" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
         

<?php
	if (strlen(@$_GET["name"]) > 0) {
		@$name = $_GET["name"];
	}

	
	if (@$_POST["sendsms"] == '1') {
		@$name = $_POST["name"];
		@$message = $_POST["message"];
		@$numero = $_POST["numero"];
		
		//Usage: dongle sms <device> <number> <message>
        //Send a SMS to <number> with the <message> from <device>
		
		$server = $asmanager->Command("dongle sms $name $numero \"$message\"");
		$arr = explode("\n", $server["data"]);
		
		//print_r($arr);
		
		echo $arr[1];
	}
?>
		 


<div id='neo-table-ref-table'>
        <table align='center' cellspacing='0' cellpadding='0' width='100%' id='neo-table1' >
        <tr class='neo-table-title-row'>
                <td class='neo-table-title-row' style='background:none;'>SIP Trunk</td>
        </tr>
	<form name='fm_sendsms' id=fm_sendsms method='post'> 
	<input type='hidden' name='name' value='<?php echo @$name; ?>'>
	<input type='hidden' name='sendsms' value='1'>
        <tbody>

			<tr class='neo-table-data-row'>
                                                <td class='neo-table-data-row table_data'>
                                                        <fieldset>
                                                                Nome<br/>
                                                                <input required type='text' name='numero' size='15' value=''/>
                                                        </fieldset>
														
														
														<fieldset>
                                                                Config<br/>
								<table align='center' cellspacing='0' cellpadding='0' width='100%' id='neo-table1' >
								<textarea required cols='40' rows='5' name='sipconfig' id='sipconfig'></textarea>
							    </table>
                                                        </fieldset>
							<br>
                                                       
                                                </td>
                                        </tr>

					<tr>
						<td class='neo-table-data-row table_data' colspan=2 align='right'>
						<button type='submit' class='btn btn-mini'><i class='icon-ok'></i> Salvar</button>
						</td>
					</tr>
			</tr>
	</tbody>
	</form>
        </table>
</div>