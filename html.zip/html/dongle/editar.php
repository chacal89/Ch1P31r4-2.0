<?php
/**
 *
 * =======================================
 * ###################################
 * RAO Telecom
 *
 * @package RAO Dongle Panel
 * @author Ricardo A. Oliveira
 * @copyright Copyright (C) 2015 - 2017 RAO Telecom. All rights reserved.
 * ###################################
 *
 * =======================================
 * raotelecom.com.br <ricardo@raotelecom.com.br>
 * 10/2017
 */

	include 'config.php';
?>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF8" />
        <title>RAO - Dongle Panel</title>
		<link rel="stylesheet" media="screen" type="text/css" href="css/jquery-ui.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/styles.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/content.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/table.css" />
       		<link rel="stylesheet" media="screen" type="text/css" href="css/bootstrap.min.css" />
		<script type='text/javascript' src='js/jquery-1.8.3.min.js'></script>
		<script type='text/javascript' src='js/jquery-ui.js'></script>
		<script type='text/javascript' src='js/jquery.ui.datepicker-pt-BR.min.js'></script>
		<script type='text/javascript' src='js/bootstrap.js'></script>
		<script type="text/javascript" language="javascript" src="js/functions.js"></script>

    </head>
    <body style="background-color: #f0f0f0;" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
         
<?php
	if (@$_GET["remove"] == "1") {
		@$id = $_GET["id"];
		
		$db = new SQLite3($database_file); 
   		$db->busyTimeout(5000);
		
		$db->exec("DELETE FROM dongle WHERE id = '$id'" ); 
		
		
		// Habilita botão .conf
		$results = $db->query("UPDATE saveconf SET save = '1' WHERE save = '0'");
		
		echo "Sucesso...";
			
		$db->close();
		unset($db);
		
	}


	if (strlen(@$_GET["name"]) > 0) {
		@$name = $_GET["name"];
		
		$db = new SQLite3($database_file); 
		$db->busyTimeout(5000);
		
		$results = $db->query("SELECT * FROM dongle WHERE name = '$name'"); 
		

		if ($row = $results->fetchArray(SQLITE3_ASSOC)) {
			$id = $row["id"];
			$name = $row["name"];
			$imei = $row["imei"];
			$grp = $row["grp"];
			$context = $row["context"];
			$rxgain = $row["rxgain"];
			$txgain = $row["txgain"];
		} else {
			// nothing
			echo "Não encontrado..";
			$id = "";
			$name = "";
			$imei = "";
			$grp = "";
			$context = "";
			$rxgain = "";
			$txgain = "";
		}

		
		$db->close();
		unset($db);		
	}


	if (@$_POST["newdongle"] == "1") {
		@$id = $_POST["id"];
		@$name = $_POST["name"];
		@$imei = $_POST["imei"];
		@$grp = $_POST["grp"];
		@$context = $_POST["context"];
		@$rxgain = $_POST["rxgain"];
		@$txgain = $_POST["txgain"];
		
		$db = new SQLite3($database_file); 
   		$db->busyTimeout(5000);
		
		$db->exec("UPDATE dongle SET name = '$name',imei = '$imei',context = '$context',rxgain = '$rxgain',txgain = '$txgain',grp = '$grp' WHERE id = '$id'" ); 
		
		// Habilita botão .conf
		$db->exec("UPDATE saveconf SET save = '1' WHERE save = '0'");
		
		echo "Sucesso...";
			/*print_r($results);
			while ($row = $results->fetchArray()) {
				$name = $row["name"];
				$imei = $row["imei"];
				$grp = $row["grp"];
				$context = $row["context"];
				$rxgain = $row["rxgain"];
				$txgain = $row["txgain"];
				
			}*/
		$db->close();
		unset($db);
	}
	
?>


<div id='neo-table-ref-table'>
        <table align='center' cellspacing='0' cellpadding='0' width='100%' id='neo-table1' >
        <tr class='neo-table-title-row'>
                <td class='neo-table-title-row' style='background:none;'>Editar dispositivo</td>
        </tr>
	<form name='fm_newdongle' id=fm_newdongle method='post'> 
	<input type='hidden' name='newdongle' value='1'>
	<input type='hidden' name='id' value='<?php echo @$id; ?>'>
        <tbody>

			<tr class='neo-table-data-row'>
                                                <td class='neo-table-data-row table_data'>
														<table border="0">
														<tr>
														<td>
                                                        <fieldset>
                                                                Nome:</td><td>
                                                                <input required type='text' name='name' size='15' value='<?php echo @$name; ?>'/>
                                                        </fieldset>
														</td>
														</tr><tr>
														<td>
														<fieldset>
                                                                Grupo:</td><td>
                                                                <input required type='text' name='grp' size='15' value='<?php echo @$grp; ?>'/>
                                                        </fieldset>
														</td>
														</tr><tr>
														<td>
														<fieldset>
                                                                IMEI:</td><td>
                                                                <input required type='text' name='imei' size='15' value='<?php echo @$imei; ?>'/>
                                                        </fieldset>
														</td>
														</tr><tr>
														<td>
														<fieldset>
                                                                Context:</td><td>
                                                                <input required type='text' name='context' size='15' value='<?php echo @$context; ?>'/>
                                                        </fieldset>
														</td>
														</tr><tr>
														<td>
														<fieldset>
                                                                RXgain:</td><td>
                                                                <input required type='text' name='rxgain' size='15' value='<?php echo @$rxgain; ?>'/>
                                                        </fieldset>
														</td>
														</tr><tr>
														<td>
														<fieldset>
                                                                TXgain:</td><td>
                                                                <input required type='text' name='txgain' size='15' value='<?php echo @$txgain; ?>'/>
                                                        </fieldset>
														</td></tr>
														</table>
                                                </td>
                                        </tr>

					<tr>
						<td class='neo-table-data-row table_data' colspan=2 align='right'>
								<a data-placement="right" data-toggle="tooltip" title="Excluir dispositivo" onClick="return confirmRemove()" class="btn btn-mini" href="editar.php?remove=1&id=<?php echo @$id; ?>">
                                <i class="icon-remove"></i> Remover
                                </a>
						
						<button type='submit' class='btn btn-mini'><i class='icon-ok'></i> Salvar</button>
						</td>
					</tr>
			</tr>
	</tbody>
	</form>
        </table>
</div>