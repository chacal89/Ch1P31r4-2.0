<?php
/**
 *
 * =======================================
 * ###################################
 * RAO Telecom
 *
 * @package RAO Dongle Panel
 * @author Ricardo A. Oliveira
 * @copyright Copyright (C) 2015 - 2017 RAO Telecom. All rights reserved.
 * ###################################
 *
 * =======================================
 * raotelecom.com.br <ricardo@raotelecom.com.br>
 * 10/2017
 */

	$database_file = '/var/www/html/dongle/dongle.db';
	$config_path = '/etc/asterisk/';
	$manager_host = 'localhost';
	$manager_user = 'raotelecom';
	$manager_pass = '1234qwer';
	
	
	function SaveConf() {
		global $database_file, $config_path;	
			
		$db = new SQLite3($database_file); 
		$db->busyTimeout(5000);
		
		// get dongle data
		$results = $db->query("SELECT * FROM dongle"); 
		
		$dongle = "";
		while($row = $results->fetchArray(SQLITE3_ASSOC)) {
			$id = $row["id"];
			$name = $row["name"];
			$imei = $row["imei"];
			$grp = $row["grp"];
			$context = $row["context"];
			$rxgain = $row["rxgain"];
			$txgain = $row["txgain"];
			
			$dongle .= "[$name]\nimei = $imei\ngroup = $grp\ncontext = $context\nrxgain = $rxgain\ntxgain = $txgain\n\n\n";
		}
		
		
		// get sip data
		$results = $db->query("SELECT * FROM sip"); 
		
		$sip = "";
		while($row = $results->fetchArray(SQLITE3_ASSOC)) {
			$id = $row["id"];
			$name = $row["name"];
			$conf = $row["conf"];
					
			$sip .= "[$name]\n$conf\n\n\n";
		}
		
		// save rao_dongle.conf
		$fp = fopen($config_path."rao_dongle.conf", "w") or die("Unable to open file!");
		fwrite($fp, $dongle);
		fclose($fp);	
		
		// save rao_dongle.conf
		$fp = fopen($config_path."rao_sip.conf", "w") or die("Unable to open file!");
		fwrite($fp, $sip);
		fclose($fp);
		
		
		// hide apply button
		$results = $db->query("UPDATE saveconf SET save = '0' WHERE save = '1'");
		
		$db->close();
		unset($db);		
			
			
	}
	
?>
