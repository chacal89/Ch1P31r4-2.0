<?php
/**
 *
 * =======================================
 * ###################################
 * RAO Telecom
 *
 * @package RAO Dongle Panel
 * @author Ricardo A. Oliveira
 * @copyright Copyright (C) 2015 - 2017 RAO Telecom. All rights reserved.
 * ###################################
 *
 * =======================================
 * raotelecom.com.br <ricardo@raotelecom.com.br>
 * 10/2017
 */


	include 'phpagi/phpagi-asmanager.php';
	include 'config.php';

	$asmanager = new AGI_AsteriskManager;
	$asmanager->connect($manager_host, $manager_user, $manager_pass);
	
							
?>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF8" />
        <title>RAO - Dongle Panel</title>
		<link rel="stylesheet" media="screen" type="text/css" href="css/jquery-ui.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/styles.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/content.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/table.css" />
       		<link rel="stylesheet" media="screen" type="text/css" href="css/bootstrap.min.css" />
		<script type='text/javascript' src='js/jquery-1.8.3.min.js'></script>
		<script type='text/javascript' src='js/jquery-ui.js'></script>
		<script type='text/javascript' src='js/jquery.ui.datepicker-pt-BR.min.js'></script>
		<script type='text/javascript' src='js/bootstrap.js'></script>
		<script type="text/javascript" language="javascript" src="js/functions.js"></script>

    </head>
    <body style="background-color: #f0f0f0;" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
         



<div id='neo-table-ref-table'>
        <table align='center' cellspacing='0' cellpadding='0' width='100%' id='neo-table1' >
        <tr class='neo-table-title-row'>
		<td class='neo-table-title-row' style='background:none;'><img src='img/modem.png' align='texttop'> Detalhamento do Modem</td>
	</tr>
  <tr class='neo-table-data-row'>
		<?php
				if (strlen(@$_GET["name"]) > 0) {
					@$name = $_GET["name"];
				
					$server = $asmanager->Command("dongle show device state $name");
					$arr = explode("\n", $server["data"]);


					for ($i=2;$i<=count($arr)-2;$i++) {
							echo "<td align='left' class='neo-table-data-row table_data'>$arr[$i]</td>
									</tr><tr class='neo-table-data-row'>";
					}
				}

		?>
                        
			</tr>
	</table>
	<div class='neo-table-header-row'></div>
</div>