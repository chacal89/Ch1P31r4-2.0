$(function() {
	$( "#datepicker1" ).datepicker();
	$( "#datepicker2" ).datepicker();
});


function confirmRestart() {
	if(confirm("Deseja Realmente Reiniciar o Modem")) {
		return true;
	} else {
		return false;
	} 
}

function confirmRemove() {
	if(confirm("Deseja Realmente Excluir o Dispositivo")) {
		return true;
	} else {
		return false;
	} 
}

function abre(url,nome,config) {
		window.open(url,nome,config);
	}

setInterval(function(){
		if($("#loaddiv").length){
			$("#loaddiv").load(location.href+" #loaddiv>*","");
		}
},5000);


function SetSmsTemplate() {
        sellength = document.forms.fm_sendsms.smstemplate.length;
        for ( i=0; i<sellength; i++)
        {
                if (document.forms.fm_sendsms.smstemplate.options[i].selected == true)
                {
                        document.forms.fm_sendsms.message.value = document.forms.fm_sendsms.smstemplate.options[i].value;
                }
        }
}

function SmsCountKeyUp(maxChar)
{
        var msg  = document.forms.fm_sendsms.message;
        var left = document.forms.fm_sendsms.charNumberLeftOutput;
        var smsLenLeft = maxChar  - msg.value.length;
        if (smsLenLeft >= 0) 
        {
                left.value = smsLenLeft;
        } 
        else 
        {
                var msgMaxLen = maxChar;
                left.value = 0;
                msg.value = msg.value.substring(0, msgMaxLen);
        }
}

function SmsCountKeyDown(maxChar)
{
        var msg  = document.forms.fm_sendsms.message;
        var left = document.forms.fm_sendsms.charNumberLeftOutput;
        var smsLenLeft = maxChar  - msg.value.length;
        if (smsLenLeft >= 0) 
        {
                left.value = smsLenLeft;
        } 
        else 
        {
                var msgMaxLen = maxChar;
                left.value = 0; 
                msg.value = msg.value.substring(0, msgMaxLen);
        }
}

function SmsTextCounter() {
        var msg = document.fm_sendsms.message;
        var msg_unicode = document.fm_sendsms.msg_unicode;
        var maxlimit = document.fm_sendsms.hiddcount.value;
        var maxlimit_unicode = document.fm_sendsms.hiddcount_unicode.value;
        var limit = maxlimit;
        var devider = 160;
        var messagelenudh;
        var result;
        if (msg_unicode.checked) {
                limit = maxlimit_unicode;
                devider = 70;
        }
        if (msg.value.length > limit) {
                msg.value = msg.value.substring(0, limit);
        }
        if (msg.value.length > devider) {
		alert("Limite máximo de caracteres ultrapassou!");
                messagelenudh = Math.ceil(msg.value.length / (devider - 7));
                result = msg.value.length + ' char : ' + messagelenudh + ' SMS' ;
                return result;
        } else {
                // otherwise, update 'characters left' counter
                result = msg.value.length + ' char : 1 SMS' ;
                return result;
        }
}

function SmsSetCounter() {
        var ilen = SmsTextCounter();
        document.fm_sendsms.txtcount.value  = ilen ;
}

$('body').tooltip({
	selector: '[rel=tooltip]'
});
// END -->
