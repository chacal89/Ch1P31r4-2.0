<?php
/**
 *
 * =======================================
 * ###################################
 * RAO Telecom
 *
 * @package RAO Dongle Panel
 * @author Ricardo A. Oliveira
 * @copyright Copyright (C) 2015 - 2017 RAO Telecom. All rights reserved.
 * ###################################
 *
 * =======================================
 * raotelecom.com.br <ricardo@raotelecom.com.br>
 * 10/2017
 */

	include 'phpagi/phpagi-asmanager.php';
	include 'config.php';

	$asmanager = new AGI_AsteriskManager;
	$asmanager->connect($manager_host, $manager_user, $manager_pass);
	
							
?>



<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF8" />
        <title>RAO - Dongle Panel</title>
		<link rel="stylesheet" media="screen" type="text/css" href="css/jquery-ui.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/styles.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/content.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/table.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/bootstrap.min.css" />
		<script type='text/javascript' src='js/jquery-1.8.3.min.js'></script>
		<script type='text/javascript' src='js/jquery-ui.js'></script>
		<script type='text/javascript' src='js/jquery.ui.datepicker-pt-BR.min.js'></script>
		<script type='text/javascript' src='js/bootstrap.js'></script>
		<script type="text/javascript" language="javascript" src="js/functions.js"></script>

    </head>
    <body style="background-color: #f0f0f0;" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
         

<div>
				<div id='neo-contentbox-leftcolumn'>
				<div id='neo-3menubox'>  <!-- mostrando contenido del menu tercer nivel -->
	  				<div class='neo-3mtabon'><a href='status2.php' style='text-decoration: none;'>Dashboard</a></div>
	  				<div class='neo-3mtab'><a  href="javascript:void(0);" style='text-decoration: none;' onClick="abre('cadastro.php','Cadastro de dispositivo','scrollbars=yes,resizable=yes,width=300,height=285')" >Cadastro de dispositivo</a></div>
					<!-- <div class='neo-3mtab'><a  href="javascript:void(0);" style='text-decoration: none;' onClick="abre('sip.php','Cadastro SIP','scrollbars=yes,resizable=yes,width=400,height=285')" >SIP</a></div> -->

	  				<div class='neo-3mtab'><a href='inboxsms.php' style='text-decoration: none;'>SMS Recebidos</a></div>
	  				<!-- <div class='neo-3mtab'><a href='relatorio.php' style='text-decoration: none;'>Relatório de Consultas</a></div> -->
	  				<!-- <div class='neo-3mtab'><a href='inboxsms.php' style='text-decoration: none;'>SMS Recebidos</a></div> -->
	  				<!-- <div class='neo-3mtabon'><a href='dongles.php' style='text-decoration: none;'>Status dos Modens</a></div> -->
	  				<!-- <div class='neo-3mtab'><a href='logoff.php' style='text-decoration: none;'>Sair</a></div> -->
										
				</div>
</div>


<div id="loaddiv">
<div id="neo-contentbox-maincolumn">
        <div class="neo-module-name-left">
</div>


<div class="neo-module-content">

<div class="neo-table-header-row"></div>
<div id='neo-table-ref-table'>
        <table align='center' cellspacing='0' cellpadding='0' width='100%' id='neo-table1' >
        <tr class='neo-table-title-row'>
                <td align='center' class='neo-table-title-row' style='background:none;'>Status dos Modens</td>
        </tr>
</div>

<?php
		
		
		//Gera .conf
		if (strlen(@$_POST["saveapply"]) > 0) {
			
						
			@$saveapply = $_POST["saveapply"];
			if ($saveapply == "1") {
				SaveConf();
				
				//reload conf
				$server = $asmanager->Command("dongle reload now");
				$server = $asmanager->Command("sip reload");
				
				echo "Sucesso...";
				//$results = $db->query("UPDATE saveconf SET save = '0' WHERE save = '1'");
			}
		}
		
		
		//Botão gera .conf
		$db = new SQLite3($database_file); 
		$db->busyTimeout(5000);
		$results = $db->query("SELECT * FROM saveconf"); 
		$row = $results->fetchArray(SQLITE3_ASSOC);
		$save = $row["save"];
		
		if ($save == "1") {
				echo "<div class='neo-table-header-row'>
				<table align='center' cellspacing='0' cellpadding='0' width='100%' id='neo-table1' >
				
				<tr class='neo-table-data-row'>
						<td align='center' class='neo-table-title-row' style='background:none;'>
						<form method='post'>
						<input type='hidden' name='saveapply' value='1'>
						<button type='submit' class='btn btn-mini'><i class='icon-ok'></i> Aplicar configuração</button>
						</td>
						</form>
				</tr>
				</div>";
		}
		$db->close();
		unset($db);
	
?>


<div id="neo-table-ref-table">
        <table align="center" cellspacing="0" cellpadding="0" width="100%" id="neo-table1" >
        <tr style="text-align: center;" class="neo-table-title-row">
        	<td class="neo-table-title-row" style="background:none;">Modem&nbsp;</td>
                <td class="neo-table-title-row">Estado&nbsp;</td>
                <td class="neo-table-title-row">Sinal&nbsp;</td>
                <td class="neo-table-title-row">Operadora&nbsp;</td>
                <td class="neo-table-title-row">IMEI&nbsp;</td>
                <td class="neo-table-title-row">Registro&nbsp;</td>
                <td class="neo-table-title-row">Grupo&nbsp;</td>
                <td class="neo-table-title-row">Número&nbsp;</td>
                <td class="neo-table-title-row">Duração&nbsp;</td>
                <td class="neo-table-title-row">Ação&nbsp;</td>
        </tr>


<?php		
$server = $asmanager->Command("dongle show devices");
$arr = explode("\n", $server["data"]);


	for ($i=2;$i<=count($arr)-2;$i++) {
		@$r_id = trim(substr($arr[$i],0,12));
		@$r_group = trim(substr($arr[$i],13,6));
		@$r_state = trim(substr($arr[$i],19,11));
		@$r_rssi = trim(substr($arr[$i],30,4));
		@$r_mode = trim(substr($arr[$i],35,4));
		@$r_submode = trim(substr($arr[$i],40,7));
		@$r_provider = trim(substr($arr[$i],48,13));
		@$r_model = trim(substr($arr[$i],63,11));
		@$r_firmware = trim(substr($arr[$i],74,17));
		@$r_imei = trim(substr($arr[$i],91,16));
		@$r_imsi = trim(substr($arr[$i],109,16));
		@$r_number = trim(substr($arr[$i],126,7));
		
		
		$server1 = $asmanager->Command("dongle show device state  ".$r_id);
		$arr1 = explode("\n", $server1["data"]);

		foreach ($arr1 as $key => $temp1) {
			if (strstr($temp1, 'GSM Registration Status')) 
			{
				$arr1_1 = preg_split("/GSM Registration Status +:/", $temp1);
				$r_regstatus = trim(rtrim($arr1_1[1]));
			}
		
		}
		
		
		$r_dialnum ="";
		$r_duration="";
		
		if (preg_match("/Dialing|Outgoing|Ring/", $r_state)) {
		//echo "ok";
			$server2 = $asmanager->Command("core show channels concise");
			$arr2 = explode("\n", $server2["data"]);

			foreach ($arr2 as $key => $temp2) {
				if (strstr($temp2, $r_id)) 
				{
					$canalStatus = explode("!", $temp2);
				//print_r($canalStatus);	
				/*	$dial = explode("/", $canalStatus[6]);
					if (strlen(@$dial[2]) > 0) {
						$dial2 = explode(",", $dial[2]);
						$r_dialnum = $dial2[0];
					}*/
					$r_dialnum = $canalStatus[7];				                    	
					$r_duration = $canalStatus[11];
					
				}
			}
		}
		//echo "$r_id, $r_group, $r_state, $r_rssi, $r_mode, $r_submode, $r_provider, $r_model, $r_firmware, $r_imei, $r_imsi, $r_number<br/>";
		
		
		if ($r_rssi == 0) {
			$r_sinal = "wifi0.gif";
		}elseif ($r_rssi >0 && $r_rssi <=6) {
			$r_sinal = "wifi1.gif";
		}elseif ($r_rssi >6 && $r_rssi <=15) {
			$r_sinal = "wifi2.gif";
		}elseif ($r_rssi >15 && $r_rssi <=20) {
			$r_sinal = "wifi3.gif";
		}elseif ($r_rssi >20 && $r_rssi <=25) {
			$r_sinal = "wifi4.gif";
		}elseif ($r_rssi >23) {
			$r_sinal = "wifi5.gif";
		}
						

?>
<tr align=center class="neo-table-data-row">
	<td class="neo-table-data-row table_data"><img title="<?php echo @$r_model; ?>" src="img/modem.png"><?php echo " ".@$r_id; ?></font></td>
        <td class="neo-table-data-row table_data"><?php echo @$r_state; ?></td>
        <td class="neo-table-data-row table_data"><img title="<?php echo @$r_rssi; ?>" src="img/<?php echo @$r_sinal; ?>" align="texttop"></td>
        <td class="neo-table-data-row table_data" title="Unknown"><?php echo @$r_provider; ?></td>
        <td class="neo-table-data-row table_data"><?php echo @$r_imei; ?></td>
        <td class="neo-table-data-row table_data"><?php echo @$r_regstatus; ?></td>
        <td class="neo-table-data-row table_data"><?php echo @$r_group; ?></td>
        <td class="neo-table-data-row table_data"><?php echo @$r_dialnum; ?></td>
        <td class="neo-table-data-row table_data"><?php echo @$r_duration; ?></td>
        <td class="neo-table-data-row table_data">
		<div align="center">
				<a  href="javascript:void(0);" onClick="abre('sms.php?name=<?php echo @$r_id; ?>','Enviar SMS','scrollbars=yes,resizable=yes,width=400,height=285')" rel="tooltip" title="Enviar SMS" class="btn btn-mini">
                                <i class="icon-envelope"></i>
                                </a>
				<a  href="javascript:void(0);" onClick="abre('deviceinfo.php?name=<?php echo @$r_id; ?>','Detalhamento Modem','scrollbars=yes,resizable=yes,width=500,height=700')" rel="tooltip" title="Info Modem" class="btn btn-mini">
                                <i class="icon-info-sign"></i>
                                </a>
				<a  href="javascript:void(0);" onClick="abre('editar.php?name=<?php echo @$r_id; ?>','Editar Modem','scrollbars=yes,resizable=yes,width=300,height=285')" rel="tooltip" title="Editar Modem" class="btn btn-mini">
                                <!-- <i class="icon-info-sign"></i> -->
								<i class="icon-wrench"></i>
                                </a>
				<a data-placement="right" data-toggle="tooltip" title="Reiniciar Modem" onClick="return confirmRestart()" class="btn btn-mini" href="command.php?exec=restart&device=<?php echo @$r_id; ?>">
                                <i class="icon-off"></i>
                                </a>
		</div>
	</td>
</tr>
<?php 
	} 
?>


		</table>
    </div>
</div>
</div>

  </body>
</html>

