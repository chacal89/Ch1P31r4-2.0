<?php
/**
 *
 * =======================================
 * ###################################
 * RAO Telecom
 *
 * @package RAO Dongle Panel
 * @author Ricardo A. Oliveira
 * @copyright Copyright (C) 2015 - 2017 RAO Telecom. All rights reserved.
 * ###################################
 *
 * =======================================
 * raotelecom.com.br <ricardo@raotelecom.com.br>
 * 10/2017
 */
 
 // Config example
 // exten => sms,1,Verbose(Incoming SMS from ${CALLERID(num)} ${BASE64_DECODE(${SMS_BASE64})})
 // exten => sms,n,Set(INBOX=${CURL(http://localhost/dongle/savesms.php?device=${DONGLENAME}&numero=${CALLERID(num)}&msg=${URIENCODE(${BASE64_DECODE(${SMS_BASE64})})})})
 // exten => sms,n,Hangup()

 	include 'phpagi/phpagi-asmanager.php';
	include 'config.php';

	$asmanager = new AGI_AsteriskManager;
	$asmanager->connect($manager_host, $manager_user, $manager_pass);
	
	
	if (strlen(@$_GET["device"]) > 0) {
		$device = $_GET["device"];
		$numero = $_GET["numero"];
		$msg = $_GET["msg"];
		$agora = date("d/m/Y - H:i:s");
		
		
		$db = new SQLite3($database_file);
		$db->busyTimeout(5000);		
   		$db->exec("INSERT INTO sms (data,modulo,numero,msg) VALUES ('$agora','$device','$numero','$msg')"); 
			
		$db->close();
		unset($db);

	}
	
	
	
	
?>
