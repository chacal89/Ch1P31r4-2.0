<?php
/**
 *
 * =======================================
 * ###################################
 * RAO Telecom
 *
 * @package RAO Dongle Panel
 * @author Ricardo A. Oliveira
 * @copyright Copyright (C) 2015 - 2017 RAO Telecom. All rights reserved.
 * ###################################
 *
 * =======================================
 * raotelecom.com.br <ricardo@raotelecom.com.br>
 * 10/2017
 */

	include 'config.php';
 
?>



<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF8" />
        <title>RAO - Dongle Panel</title>
		<link rel="stylesheet" media="screen" type="text/css" href="css/jquery-ui.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/styles.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/content.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/table.css" />
       		<link rel="stylesheet" media="screen" type="text/css" href="css/bootstrap.min.css" />
		<script type='text/javascript' src='js/jquery-1.8.3.min.js'></script>
		<script type='text/javascript' src='js/jquery-ui.js'></script>
		<script type='text/javascript' src='js/jquery.ui.datepicker-pt-BR.min.js'></script>
		<script type='text/javascript' src='js/bootstrap.js'></script>
		<script type="text/javascript" language="javascript" src="js/functions.js"></script>
    <body style="background-color: #f0f0f0;" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
         

<div>
				<div id='neo-contentbox-leftcolumn'>
				<div id='neo-3menubox'>  <!-- mostrando contenido del menu tercer nivel -->
	  				<div class='neo-3mtab'><a href='index.php' style='text-decoration: none;'>Dashboard</a></div>
	  				<div class='neo-3mtab'><a  href="javascript:void(0);" style='text-decoration: none;' onClick="abre('cadastro.php','Cadastro de dispositivo','scrollbars=yes,resizable=yes,width=300,height=285')" >Cadastro de dispositivo</a></div>
				<!--	<div class='neo-3mtab'><a  href="javascript:void(0);" style='text-decoration: none;' onClick="abre('sip.php','Cadastro SIP','scrollbars=yes,resizable=yes,width=400,height=285')" >SIP</a></div> -->

	  				<div class='neo-3mtabon'><a href='inboxsms.php' style='text-decoration: none;'>SMS Recebidos</a></div>
	  				<!-- <div class='neo-3mtab'><a href='relatorio.php' style='text-decoration: none;'>Relatório de Consultas</a></div> -->
	  				<!-- <div class='neo-3mtab'><a href='inboxsms.php' style='text-decoration: none;'>SMS Recebidos</a></div> -->
	  				<!-- <div class='neo-3mtabon'><a href='dongles.php' style='text-decoration: none;'>Status dos Modens</a></div> -->
	  				<!-- <div class='neo-3mtab'><a href='logoff.php' style='text-decoration: none;'>Sair</a></div> -->
										
				</div>
</div>


<div id="neo-contentbox-maincolumn">
        <div class="neo-module-name-left">
</div>


<div class="neo-module-content">

<div class="neo-table-header-row"></div>
<div id="neo-table-ref-table">
<br>
	<div align=center>
        	<form action="inboxsms.php" method="GET" class="form-inline">
                	<input type="hidden" name="do" value="busca">
                        Data Inicial: <i class="icon-calendar"></i><input required id="datepicker1" name="int_date" type="text" value="<?php echo date("d/m/Y"); ?>">&nbsp;&nbsp;
                        Data Final: <i class="icon-calendar"></i><input required id="datepicker2" name="end_date" type="text" value="<?php echo date("d/m/Y"); ?>">
                        <input class="button" type="submit" >
                </form>
        </div>
	<tr>
		        </tr>




        <table align="center" cellspacing="0" cellpadding="0" width="100%" id="neo-table1" >
        <tr style="text-align: center;" class="neo-table-title-row">
                <td class="neo-table-title-row">Data&nbsp;</td>
                <td class="neo-table-title-row">Dongle&nbsp;</td>
                <td class="neo-table-title-row">Número&nbsp;</td>
                <td class="neo-table-title-row">Mensagem&nbsp;</td>
        </tr>
		<?php
			$ct=0;
			if (@$_GET["do"] == "busca") {
				@$inicio = @$_GET["int_date"];
				@$inicio .= " - 00:00:00";
				@$fim = @$_GET["end_date"];
				@$fim .= " - 23:59:59";
				
				$db = new SQLite3($database_file); 
				$db->busyTimeout(5000);
				
				$results = $db->query("SELECT * FROM sms WHERE data BETWEEN '$inicio' AND '$fim'");
								
				while ($row = $results->fetchArray(SQLITE3_ASSOC)) {
					$data = $row["data"];
					$modulo = $row["modulo"];
					$numero = $row["numero"];
					$msg = $row["msg"];
					
					echo "<tr align='center' class='neo-table-data-row'>
							<td class='neo-table-data-row table_data'>$data</td>
							<td class='neo-table-data-row table_data'>$modulo</td>
							<td class='neo-table-data-row table_data'>$numero</td>
							<td class='neo-table-data-row table_data'>$msg</td>
						</tr>";
					$ct++;		
				}
				$db->close();
				unset($db);
			}
		?>
		
		
		
		
	<tr align='center' class='neo-table-data-row'>
                <td colspan="6" class='neo-table-data-row table_data'>Total de Mensagens: <?php echo @$ct ?></td>
        </tr>

        </table>
</div>

</div>
    </body>
</html>

