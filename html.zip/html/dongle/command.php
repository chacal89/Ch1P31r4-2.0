
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF8" />
        <title>RAO - Dongle Panel</title>
		<link rel="stylesheet" media="screen" type="text/css" href="css/jquery-ui.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/styles.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/content.css" />
		<link rel="stylesheet" media="screen" type="text/css" href="css/table.css" />
       		<link rel="stylesheet" media="screen" type="text/css" href="css/bootstrap.min.css" />
		<script type='text/javascript' src='js/jquery-1.8.3.min.js'></script>
		<script type='text/javascript' src='js/jquery-ui.js'></script>
		<script type='text/javascript' src='js/jquery.ui.datepicker-pt-BR.min.js'></script>
		<script type='text/javascript' src='js/bootstrap.js'></script>
		<script type="text/javascript" language="javascript" src="js/functions.js"></script>

    </head>
    <body style="background-color: #f0f0f0;" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<?php
/**
 *
 * =======================================
 * ###################################
 * RAO Telecom
 *
 * @package RAO Dongle Panel
 * @author Ricardo A. Oliveira
 * @copyright Copyright (C) 2015 - 2017 RAO Telecom. All rights reserved.
 * ###################################
 *
 * =======================================
 * raotelecom.com.br <ricardo@raotelecom.com.br>
 * 10/2017
 */

	include 'phpagi/phpagi-asmanager.php';
	include 'config.php';

	$asmanager = new AGI_AsteriskManager;
	$asmanager->connect($manager_host, $manager_user, $manager_pass);
	
	
	if ($_GET["exec"] == "restart") {
		if (strlen(@$_GET["device"]) > 0) {
				$device = $_GET["device"];
				$server = $asmanager->Command("dongle stop now $device");
				$server = $asmanager->Command("dongle start $device");
		}
	}
	
	
	
	
	
?>

<script>window.location='index.php'</script>  </body>
</html>


