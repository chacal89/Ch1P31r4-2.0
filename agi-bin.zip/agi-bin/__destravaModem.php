#!/usr/bin/php5 -q

<?php

  require_once('phpagi.php');
  set_time_limit(10);

  $agi = new AGI();

  $tronco = $argv[1];
  $dongle = $argv[2];
  $modem = $argv[3];
  $tempo = $argv[4];
  $dt = date("d/m/Y H:i:s ");

  if( $dongle == 3 and $tronco == 0 ) {
        $output = shell_exec("asterisk -x 'dongle stop now $modem'");
        sleep($tempo);
        $output = shell_exec("asterisk -x 'dongle start $modem'");
        $output = shell_exec("echo $dt $modem destravou >> /var/log/asterisk/modens.log");
  }

?>
