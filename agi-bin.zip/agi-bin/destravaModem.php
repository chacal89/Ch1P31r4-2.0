#!/usr/bin/php5 -q

<?php

  require_once('phpagi-asmanager.php');
  include_once('phpagi.php');
  set_time_limit(10);

  $agi = new AGI();
  $asm = new AGI_AsteriskManager();


  $tronco = $argv[1];
  $dongle = $argv[2];
  $modem = $argv[3];
  $tempo = $argv[4];
  $dt = date("d/m/Y H:i:s ");


   if ($asm->connect("localhost","raotelecom","1234qwer"))
   {

        if( $dongle == 3 and $tronco == 0 ) {
                //$output = shell_exec("asterisk -x 'dongle stop now $modem'");
                //$res = $asm->send_request("DongleStop","$modem");
                $res = $asm->command("dongle stop now $modem");
                sleep($tempo);
                //$output = shell_exec("asterisk -x 'dongle start $modem'");
                //$res = $asm->send_request("DongleStart","$modem");
                $res = $asm->command("dongle start $modem");
                $output = shell_exec("echo $dt $modem destravou >> /var/log/asterisk/modens.log");
        }

   $asm->disconnect();

   }

?>

