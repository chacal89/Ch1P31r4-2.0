#!/usr/bin/php
<?php

error_reporting(0);
$dt=System(date);
$free="Free";
$dialing="Dialing";
$outgoing="Outgoing";
$ring="Ring";
$gsmout="GSM";
$not="Not";
$sms="SMS";

//System("clear");

$i=1;
$comerro=0;
$ok=0;
while ( $i <= 32 ){

if ( $i <= 9 )
	$sementegrep = "Modulo0" .$i;
		else
		    $sementegrep = "Modulo" .$i;
//echo $sementegrep;


	$Modulo[]=System("asterisk -x 'dongle show devices' | grep '$sementegrep'");
	//echo "asterisk -x 'dongle show devices' | grep Modulo$numMod";
	System("clear");

//	$strModem = $Modulo[$i];
//
//print_r( $Modulo);
//
//	if ( !strpos($strModem, $free) )
//	$comerro++;
//		else
//		    $ok++;


$limpo = array_filter($Modulo);
$i++;
}

$tamanho = sizeof($limpo);
System("clear");
$i=0;
$ret="";
foreach ( $limpo as $linha ){
	$strModem = $Modulo[$i];

	//echo $tamanho;

//echo $strModem ."\n";

$nomeModulo = substr($strModem, 0, 8);

echo $nomeModulo ."\n";

	if ( !strpos($strModem, $free) ){
	$comerro++;
	System("echo '$nomeModulo travou em $dt' >> /var/log/asterisk/resumo.log");
	$verificaCanal=System("asterisk -x 'core show channels' | grep '$nomeModulo' | awk '{print$3}'");

	$resposta = trim($verificaCanal);
	if ( empty($resposta) ){
		$ret .= "$nomeModulo TRAVADO, reiniciar\n";
	System("asterisk -x 'dongle restart now $nomeModulo'");


	} else {

		$ret .=  "$nomeModulo em Chamada, manter\n";
		$ok++;
		$comerro--;
}

	//echo $verificaModem ."\n";

	//echo $verificaCanal;

		} 

else {

//	System("echo '$nomeModulo travou em $dt' >> /var/log/asterisk/resumo.log");
//	$verificaCanal=System("asterisk -x 'core show channels' | grep '$nomeModulo' | awk '{print$3}'");

	//echo $verificaModem ."\n";
	//echo $verificaCanal;
		$ret .=  "$nomeModulo Livre, manter\n";


			$ok++;
			}
//echo "$sementegrep e: $not\n\n";
$i++;
}




//print_r ($limpo);
System("clear");
echo $ret;
echo "Modem com Erro: $comerro\n";
echo "Modem ok: $ok\n";


//$i=1;
//while ( $testaModem = $limpo ){
//	$Modem = explode($limpo[$i], "    " );
//		print_r($Modem);
//$i++;
//}

//print_r($limpo);


/*

modulo=${Modulo}
Total=$((Total-1))

i=0
while [ $i -le $Total ]
do
verificaCanal=`asterisk -x 'core show channels' | grep "${modulo[$i]}" | awk '{print$3}'`
     if [ -z $verificaCanal ] ; then
        verificaModem=`asterisk -x 'dongle show devices' | grep "${modulo[$i]}" | awk '{print$3}'`
        if [ "$verificaModem" != "$free" ]; then
                asterisk -rx "dongle restart now ${modulo[$i]}"
                echo $dt "${modulo[$i]} travou em:" $verificaModem >> /var/log/asterisk/relatorio.log
          else
            echo "${modulo[$i]} em Free"
        fi
verificaCanal=`asterisk -x 'core show channels' | grep "${modulo[$i]}" | awk '{print$3}'`
     else
        echo "canal usando ${modulo[$i]}"
     fi
   (( i++ ))
done
*/
?>

