#!/usr/bin/php5 -q
<?php
//$debug = "off";
$debug = "on";

$servico = "asterisk";

$__retorno = trim(shell_exec("pgrep $servico | wc -l"));

	$t = $__retorno - 1;

		if ($t > 0) {
		    echo "$servico Rodando\n";
		    	if ( $debug == "on" )
				exec('echo "EXECUTADO EM: `date`" >> /var/log/asterisk/statusexec.log', $output, $return);
		    } else {
			       exec('echo "Asterisk Reiniciado em: `date`" >> /var/log/asterisk/statusasterisk.log', $output, $return);
			       exec("service $servico restart", $output, $return);
		   }
?>

