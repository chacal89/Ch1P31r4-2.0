#!/usr/bin/php
<?php
error_reporting(0);
$i=1;
while ( $i <= 32 ){
if ( $i <= 9 )
	$sementegrep = "Modulo0" .$i;
		else
		    $sementegrep = "Modulo" .$i;
	$Modulo[]=System("asterisk -x 'dongle show devices' | grep '$sementegrep'");
	System("clear");
$limpo = array_filter($Modulo);
$i++;
}
$tamanho = sizeof($limpo);
System("clear");
$i=0;
$ret="";
foreach ( $limpo as $linha ){
	$strModem = $limpo[$i];
$nomeModulo = substr($strModem, 0, 8);
	System("asterisk -rx 'dongle cmd $nomeModulo AT+CPMS=\"SM\",\"SM\",\"SM\"'");
	System("sleep 2");
	System("asterisk -rx 'dongle cmd $nomeModulo AT+CMGD=1,4'");
	System("sleep 2");
	System("asterisk -rx 'dongle cmd $nomeModulo AT+CPMS=\"ME\",\"ME\",\"ME\"'");
	System("sleep 2");
	System("asterisk -rx 'dongle cmd $nomeModulo AT+CMGD=1,4'");
$i++;
	} 
?>

